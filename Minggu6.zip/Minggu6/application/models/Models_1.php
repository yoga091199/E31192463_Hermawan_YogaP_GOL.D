<?php
class Models_1 extends CI_Model
{
  public $txt = "Hello World dari CI Model";
  public $txtTugas2 = "Hello Tugas 2";
  public $txtTugas3 = "Hello Tugas 3";
}
